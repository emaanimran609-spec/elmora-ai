import { useState } from 'react'
import './App.css'

const starterPrompts = [
  { icon: '✦', title: 'Explain quantum computing', detail: 'in simple terms' },
  { icon: '✎', title: 'Help me write', detail: 'a professional email' },
  { icon: '⌘', title: 'Brainstorm ideas', detail: 'for a weekend project' },
  { icon: '⌁', title: 'Plan a trip', detail: 'to northern Pakistan' },
]

const initialChats = [
  { id: 1, title: 'Welcome to ElmoraAI' },
  { id: 2, title: 'Weekend trip ideas' },
  { id: 3, title: 'Understanding neural networks' },
]

function PakMark({ small = false }) {
  return <span className={`pak-mark${small ? ' small' : ''}`} aria-hidden="true" />
}

function App() {
  const [message, setMessage] = useState('')
  const [chats, setChats] = useState(initialChats)
  const [activeChat, setActiveChat] = useState(1)
  const [messages, setMessages] = useState([])
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isDark, setIsDark] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [ownerName, setOwnerName] = useState(() => localStorage.getItem('pakai-owner-name') || 'Emaan Imran')

  const startNewChat = () => {
    const nextChat = { id: Date.now(), title: 'New conversation' }
    setChats((current) => [nextChat, ...current])
    setActiveChat(nextChat.id)
    setMessages([])
    setMessage('')
    setIsSidebarOpen(false)
  }

  const sendMessage = async (text = message) => {
    const trimmed = text.trim()
    if (!trimmed || isLoading) return
    const userMessage = { id: messages.length + 1, role: 'user', content: trimmed }
    const conversation = [...messages, userMessage]
    setMessages(conversation)
    setMessage('')
    setError('')
    setIsLoading(true)
    setChats((current) => current.map((chat) => chat.id === activeChat && chat.title === 'New conversation' ? { ...chat, title: trimmed.slice(0, 28) } : chat))

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerName, messages: conversation.map(({ role, content }) => ({ role, content })) }),
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'ElmoraAI could not answer right now.')
      setMessages((current) => [...current, { id: current.length + 1, role: 'assistant', content: data.content }])
    } catch (requestError) {
      setError(requestError.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className={isDark ? 'app-shell dark' : 'app-shell'}>
      <aside className={`sidebar${isSidebarOpen ? ' open' : ''}`}>
        <div className="brand"><PakMark /><span>ElmoraAI</span></div>
        <button className="new-chat" onClick={startNewChat}><span>＋</span> New chat <kbd>Ctrl K</kbd></button>
        <div className="chat-list"><p className="list-label">Your chats</p>{chats.map((chat) => <button className={`chat-item${activeChat === chat.id ? ' active' : ''}`} key={chat.id} onClick={() => { setActiveChat(chat.id); setMessages([]); setIsSidebarOpen(false) }}><span className="chat-bubble">◌</span>{chat.title}</button>)}</div>
        <div className="sidebar-bottom"><button className="side-link"><span>◇</span> Explore</button><button className="side-link" onClick={() => setIsSettingsOpen(true)}><span>⚙</span> Settings</button><div className="profile"><div className="avatar">I</div><span>Imran Khan</span><span className="more">•••</span></div></div>
      </aside>
      <section className="chat-area">
        <header className="topbar"><button className="menu-button" aria-label="Open sidebar" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>☰</button><div className="mobile-brand"><PakMark small /><strong>ElmoraAI</strong></div><div className="model-select">ElmoraAI <span>⌄</span></div><button className="theme-toggle" aria-label="Toggle dark mode" onClick={() => setIsDark(!isDark)}>{isDark ? '☼' : '☾'}</button></header>
        <div className="conversation">{messages.length === 0 ? <div className="welcome"><div className="welcome-mark"><PakMark /></div><h1>How can I help you today?</h1><p>Ask anything, create something, or just start a conversation.</p><div className="prompt-grid">{starterPrompts.map((prompt) => <button className="prompt-card" key={prompt.title} onClick={() => sendMessage(prompt.title)}><span className="prompt-icon">{prompt.icon}</span><span><strong>{prompt.title}</strong><small>{prompt.detail}</small></span><span className="arrow">↗</span></button>)}</div></div> : <div className="message-list">{messages.map((item) => <div className={`message-row ${item.role}`} key={item.id}><div className="message-avatar">{item.role === 'user' ? 'I' : <PakMark small />}</div><div className="message-copy"><span className="message-name">{item.role === 'user' ? 'You' : 'ElmoraAI'}</span><p>{item.content}</p></div></div>)}{isLoading && <div className="message-row assistant"><div className="message-avatar"><PakMark small /></div><div className="message-copy"><span className="message-name">ElmoraAI</span><p className="typing"><i></i><i></i><i></i></p></div></div>}{error && <div className="request-error">{error}</div>}</div>}</div>
        <div className="composer-wrap"><form className="composer" onSubmit={(event) => { event.preventDefault(); sendMessage() }}><textarea value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage() } }} placeholder="Message ElmoraAI..." rows="1" /><div className="composer-actions"><button type="button" className="attach" aria-label="Attach file">＋</button><span className="composer-hint">ElmoraAI can make mistakes. Check important info.</span><button type="submit" className="send" disabled={!message.trim() || isLoading} aria-label="Send message">↑</button></div></form></div><footer>© 2026 ElmoraAI <span>·</span> Your intelligent companion</footer>
      </section>
      {isSettingsOpen && <div className="settings-backdrop" onClick={() => setIsSettingsOpen(false)}><section className="settings-dialog" role="dialog" aria-modal="true" aria-labelledby="settings-title" onClick={(event) => event.stopPropagation()}><header><h2 id="settings-title">Settings</h2><button type="button" className="settings-close" aria-label="Close settings" onClick={() => setIsSettingsOpen(false)}>×</button></header><label htmlFor="owner-name">Owner / runner name</label><input id="owner-name" value={ownerName} onChange={(event) => { setOwnerName(event.target.value); localStorage.setItem('pakai-owner-name', event.target.value) }} maxLength={80} /><p>ElmoraAI will use this name when asked about the owner or runner.</p></section></div>}
    </main>
  )
}

export default App
