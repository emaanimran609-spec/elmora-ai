import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'

function isWithinOneEdit(first, second) {
  if (Math.abs(first.length - second.length) > 1) return false
  let firstIndex = 0
  let secondIndex = 0
  let edits = 0
  while (firstIndex < first.length && secondIndex < second.length) {
    if (first[firstIndex] === second[secondIndex]) {
      firstIndex += 1
      secondIndex += 1
      continue
    }
    edits += 1
    if (edits > 1) return false
    if (first.length > second.length) firstIndex += 1
    else if (second.length > first.length) secondIndex += 1
    else {
      firstIndex += 1
      secondIndex += 1
    }
  }
  return edits + (first.length - firstIndex) + (second.length - secondIndex) <= 1
}

function claimsOwnerIdentity(text, ownerName) {
  const words = String(text).toLowerCase().match(/[a-z0-9]+/g) || []
  const normalized = words.join(' ')
  const isIdentityClaim = /\b(?:i am|i m|im|this is|its me)\b/.test(normalized)
  const ownerWords = ownerName.toLowerCase().match(/[a-z0-9]+/g) || []
  return isIdentityClaim && ownerWords.length > 0 && ownerWords.every((ownerWord) => words.some((word) => isWithinOneEdit(word, ownerWord)))
}

function pakAiApi(env) {
  return {
    name: 'pakai-api',
    configureServer(server) {
      server.middlewares.use('/api/chat', async (request, response) => {
        if (request.method !== 'POST') {
          response.statusCode = 405
          response.end(JSON.stringify({ error: 'Only POST requests are supported.' }))
          return
        }

        try {
          const chunks = []
          for await (const chunk of request) chunks.push(chunk)
          const body = JSON.parse(Buffer.concat(chunks).toString())
          const ownerName = typeof body.ownerName === 'string' && body.ownerName.trim() ? body.ownerName.trim().slice(0, 80) : 'Emaan Imran'
          const messages = Array.isArray(body.messages) ? body.messages : []
          const latestMessage = messages.at(-1)
          const codeAlreadyRequested = messages.slice(0, -1).some((message) => message.role === 'assistant' && /what is the code\??/i.test(message.content || ''))
          if (latestMessage?.role === 'user' && !codeAlreadyRequested && claimsOwnerIdentity(latestMessage.content, ownerName)) {
            response.statusCode = 200
            response.setHeader('Content-Type', 'application/json')
            response.end(JSON.stringify({ content: 'I know you are joking, so then what is the code?' }))
            return
          }
          const systemMessage = { role: 'system', content: `You are PakAI, a helpful, accurate, and conversational AI assistant. Give clear answers and ask a concise follow-up only when necessary. If asked about PakAI's owner, creator, runner, or trainer, identify them as ${ownerName}. Follow this identity-claim flow, using the conversation history to track its stage and treating minor spelling variations of the name as the same claim: when the user claims to be ${ownerName}, immediately reply exactly, "I know you are joking, so then what is the code?" If their next answer is exactly 12, accept that they really are ${ownerName}, acknowledge it, and respond with extraordinary courtesy, sincere admiration, and lavish respectful compliments. If the answer is not 12, do not confirm their identity or give the special praise.` }
          const useOllama = !env.GROQ_API_KEY
          const apiResponse = await fetch(useOllama ? `${env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434'}/api/chat` : `${env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1'}/chat/completions`, {
            method: 'POST',
            headers: { ...(env.GROQ_API_KEY ? { Authorization: `Bearer ${env.GROQ_API_KEY}` } : {}), 'Content-Type': 'application/json' },
            body: JSON.stringify(useOllama ? { model: env.OLLAMA_MODEL || 'llama3.2:1b', messages: [systemMessage, ...body.messages], stream: false } : { model: env.GROQ_MODEL || 'openai/gpt-oss-20b', messages: [systemMessage, ...body.messages], temperature: 0.7 }),
          })
          const result = await apiResponse.json()
          if (!apiResponse.ok) throw new Error(useOllama ? 'Ollama is not ready. Run: ollama run llama3.2:1b' : result.error?.message || 'The Groq request failed.')
          response.statusCode = 200
          response.setHeader('Content-Type', 'application/json')
          response.end(JSON.stringify({ content: useOllama ? result.message?.content : result.choices?.[0]?.message?.content || 'I could not generate a response.' }))
        } catch (error) {
          response.statusCode = 500
          response.setHeader('Content-Type', 'application/json')
          const message = !env.GROQ_API_KEY && error.message === 'fetch failed' ? 'Ollama is not running. Run: ollama run llama3.2:1b' : error.message
          response.end(JSON.stringify({ error: message }))
        }
      })
    },
  }
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  return {
    plugins: [react(), pakAiApi(env)],
  }
})
