# PakAI

PakAI is a React + Vite chat interface powered by Groq.

## Run locally

1. Copy `.env.example` to `.env`.
2. Set `GROQ_API_KEY` to a key from [Groq Console](https://console.groq.com/keys).
3. Start the app with `npm run dev`.

The API key is used only by the Vite server middleware and is never exposed to the browser. If `GROQ_API_KEY` is empty, the app falls back to local Ollama using the settings in `.env.example`.

## Available scripts

- `npm run dev` starts the development server.
- `npm run build` creates a production client build.
- `npm run lint` checks the source files.

This template provides a minimal setup to get React working in Vite with HMR and some Oxlint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the Oxlint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and Oxlint's TypeScript related rules in your project.
